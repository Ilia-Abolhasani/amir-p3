/* main.c -- Mapping small RNA sequencing data to genome (Only perfect matched ones) */

#include "stdio.h"
#include "malloc.h"
#include "string.h"
#include "Structure.h"
#include "Sub.h"
#include "DefHead.h"
#include "Create.h"
#include "Map.h"
#define  BUFFER 1000

main (int argc, char *argv[])
{
	if (argc != 4)
	{
		printf ("Filenum not fit\n");
		return (0);
	}
	FILE *rna_file, *chr_file, *out_file;
	sr * head, * tail;
	head = defHead ();	//create tree head node
	char name[BUFFER];
     char seq[BUFFER];

/* Read small RNA data, and build tree structure */
	if ((rna_file = fopen (argv[1],"r")) == NULL)
	{
		printf ("Cannot open file 1\n");
		return (0);
	}
	while (!feof (rna_file))
	{
		int i = 0;
          memset(name, 0, sizeof(name));
          memset(seq , 0, sizeof(seq) );
		fscanf (rna_file, "%s\t%s\n", name, seq);
		tail = create (head, strlen(seq), seq);
		if (tail == head){
			continue;
		}
          if ((tail->l = (char *) malloc ((strlen(name)+1)*sizeof(char))) == NULL){
               printf ("Cannot get the memory!"); return(0);
          }
		strcpy (tail->l, name);
	}
	fclose (rna_file);

/* Read chromosome data, and compared with sRNA */
	if ((chr_file = fopen (argv[2],"r")) == NULL)
	{
		printf ("Cannot open file 2\n");
		return (0);
	}
	if ((out_file = fopen (argv[3],"wb+")) == NULL)
	{
		printf ("Cannot open file 3\n");
		return (0);
	}
	while (!feof (chr_file))
	{
		char tag [BUFFER] = {'0'};
		char chr [40] = {'0'};	//40 is match to seq [40]
		char chr_reverse [40] = {'0'};
		char ch;
		long m = 0;
		int c = 0;
		ch = fgetc (chr_file);
		while (ch != EOF)
		{
			if (ch == '\n')
			{
				if (m < 40) m = 40;
				while (chr[10] != '0')
				{
					map (out_file, head, tag, chr, m, 0);
					Back_Add (chr, '0', sizeof(chr));
					m++;
				}
				c = 0;	//one line is done, every variables return to 0
				m = 0;
				printf ("%s is Done\n", tag);
				memset (tag, 0, sizeof(tag));
				memset (chr, 0, sizeof(chr));
				memset (chr_reverse, 0, sizeof(chr_reverse));
			 }else{
			 	if (ch != '\t')
			 	{
			 		if (c == 0)
					{
						tag[m] = ch;	//the first colomn is tag
			 		}else{
						if (m < 40)
						{
							chr[m] = ch;
							Front_Add (Com_BP (ch), chr_reverse, sizeof(chr_reverse));
							map (out_file, head, tag, chr_reverse, 0, m);
						}else{
							map (out_file, head, tag, chr, m, 0);
							Back_Add (chr, ch, sizeof(chr));
							Front_Add (Com_BP (ch), chr_reverse, sizeof(chr_reverse));
							map (out_file, head, tag, chr_reverse, 0, m);
						}
					}
					m++;    //m is the position of file point
	 			}else{
					if (c == 0)
					tag[m] = '\0';	//only the first colomn is tag name
					c++;
					m = 0;
	 			}
	 		}
			ch = fgetc (chr_file);
		}
	}
	fclose (chr_file);
	fclose (out_file);

}






