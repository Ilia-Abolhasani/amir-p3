#!/usr/bin/perl

package SmRNA_Cluster;
use strict;

sub _SmRNA_Cluster{

my $ref_individual_reads = 1; #Pick ones, not drop ones.
my $ref_gap = 0; #minimal interval between two nearest smRNAs.
my $ref_loci = 0; #maximal loci number. 0 for no loci control.
my $ref_total_last_reads = 1; #minimal total reads of cluster.

(my $_in_file, my $_out_file, $ref_gap, $ref_loci, $ref_total_last_reads, $ref_individual_reads) = @_;

my @num;
my $total_num = 1;
my @last_reads;
my $total_last_reads;
my $last_chr;
my $last_start;
my $last_end;
my $loci = 0;
my $last_chain;
my $highest_reads = 0;
my @highest_smRNA;

open IN  ,  "<$_in_file" or die $!;
open OUT ,  ">$_out_file" or die $!;
print OUT "Length_Loci_Num_ReadsRatio\tNo.OfsRNAs\tReadsOfsRNAs\tCHR\tStart\tEnd\tChain\tHiID\tHiStart\tHiEnd\n";
while (<IN>){
	chomp;
	my @line  = split /\t/,$_;
	my @reads = split /\_/,$line[0];
	shift @reads; my $locus = shift @reads; shift @reads; shift @reads;
	my $total_reads;
	map { $total_reads += $_; } @reads;
	my $chr   = $line[1];
	my $start = $line[3];
	my $end   = $line[4];
	my $chain = $line[2];
	next if ($total_reads < $ref_individual_reads);   #reads control
	next if ($locus > $ref_loci and $ref_loci != 0);   #loci control
	if ($chr eq $last_chr and $start <= $last_end+1+$ref_gap){
		if ($total_reads > $highest_reads){
			$highest_reads = $total_reads;
			@highest_smRNA = @line;
		}
		$start = $last_start if ($start>$last_start);
		$end   = $last_end   if ($end  <$last_end  );
		for my $i (0..$#reads){
			$num[$i]++ if ($reads[$i] != 0);
			$reads[$i] = $reads[$i]+$last_reads[$i];
		}
		$total_num++;
	}else{
		my $len = $last_end-$last_start+1;
		if ($total_last_reads >= $ref_total_last_reads){ #cluster control
			my $reads_ratio = int(100*$highest_reads/$total_last_reads);
			print OUT "$len\_$loci\_$total_num\_$reads_ratio\t".join("_",@num)."\t".join("_",@last_reads)."\t$last_chr\t$last_start\t$last_end\t$last_chain\t$highest_smRNA[0]\t$highest_smRNA[3]\t$highest_smRNA[4]\n";
		}
		@num = split //, (0 x ($#num+1));
		$total_num = 1;
		$total_last_reads = 0;
		$loci = 0;
		$highest_reads = $total_reads;
		@highest_smRNA = @line;
		for my $i (0..$#reads){
			$num[$i]++ if ($reads[$i] != 0);
		}
	}
	$last_chr   = $chr;
	$last_start = $start;
	$last_end   = $end;
	$last_chain = $chain;
	@last_reads = @reads;
	$total_last_reads += $total_reads;
	$loci += $locus;
}
my $len = $last_end-$last_start+1;
if ($total_last_reads >= $ref_total_last_reads){ #cluster control
	my $reads_ratio = int(100*$highest_reads/$total_last_reads);
	print OUT "$len\_$loci\_$total_num\_$reads_ratio\t".join("_",@num)."\t".join("_",@last_reads)."\t$last_chr\t$last_start\t$last_end\t$last_chain\t$highest_smRNA[0]\t$highest_smRNA[3]\t$highest_smRNA[4]\n";
}
close IN;
close OUT;

}

1;


