#!/usr/bin/perl

package Auto_NaFold;
use strict;

sub _NaFold {

my $file = shift;
open NAFOLD , "| nafold" or die $!;
select (NAFOLD);
print << 'CODE';

2
CODE
print "$file\n";
print << 'CODE';

















n
CODE
print "$file.out\n";
print << 'CODE';

y
CODE
print "$file.det\n";
print << 'CODE';
10
CODE
select(STDOUT);
close (NAFOLD);

}

1;


