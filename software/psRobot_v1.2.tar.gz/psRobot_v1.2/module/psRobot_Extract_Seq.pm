#!/usr/bin/perl

package Extract_Seq;
use strict;

sub _Extract_Seq{
	my ($_start, $_end, $_uc_start, $_uc_end, $_strand, $_data_seq, $_up, $_down) = @_;
	my $_len = $_end-$_start+1;
	my $_uc_len = $_uc_end-$_uc_start+1;
	my $_seq;
	if ($_strand eq '-'){
		my $_tmp_start = $_start;
		$_start = $_start-$_down;
		if ($_start < 1){
			$_down  = $_tmp_start-1;
			$_start = 1;
		}
		$_len   = $_up+$_len+$_down;
		$_seq = lc( substr($_data_seq, $_start-1, $_len) );
		substr($_seq, $_uc_start-$_start, $_uc_len) = uc (substr($_seq, $_uc_start-$_start, $_uc_len));
		$_seq =~ tr/ATGCUatgcu/TACGAtacga/;
		$_seq = reverse ($_seq);
	}else{
		my $_tmp_start = $_start;
		$_start = $_start-$_up;
		if ($_start < 1){
			$_start = 1;
			$_up    = $_tmp_start-1;
		}
		$_len   = $_up+$_len+$_down;
		$_seq = lc( substr($_data_seq, $_start-1, $_len) );
		substr($_seq, $_uc_start-$_start, $_uc_len) = uc (substr($_seq, $_uc_start-$_start, $_uc_len));
	}
	return ($_seq, $_start, $_start+length($_seq)-1);
}

1;


