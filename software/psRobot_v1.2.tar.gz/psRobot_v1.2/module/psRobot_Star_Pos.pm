#!/usr/bin/perl

package Star_Pos;
use strict;

sub _POS{
        my $line = shift;
        my @line = split /\n/, $line;
	my ($len, $id) = (split /\s+/, $line[2])[4,6];
        $id = (split /\|\|/, $id)[0];
	my @pos;
        my $i;
        my $loop = 0;
        for ($i=6; $i<=$#line-4; $i=$i+8){
                @pos = &Seek_Pos ($line[$i], $line[$i+1], $line[$i+2], $line[$i+3], $len);
        }
	unshift @pos, $id;
	return @pos;
}

sub Seek_Pos{
        my @line = @_;
        my @plus_match_info;
        my @minus_match_info;
        my $plus;
        my $minus;
        my $picked_plus;
        my $picked_minus;
	my $_len = $line[4];
        ############Line 1################
        while ($line[0] =~ m/[ATCGUN]/g){
                my $pos = pos($line[0]);
                $plus_match_info[$pos] = 2; #sRNA Mis-match
        }
        while ($line[0] =~ m/\-/g){
                my $pos = pos($line[0]);
                $plus_match_info[$pos] = 5; #Gap
        }
        while ($line[0] =~ m/[atcgun]/g){
                my $pos = pos($line[0]);
                $plus_match_info[$pos] = 4; #non sRNA Mis-match
        }
        while ($line[0] =~ m/[\.\\]/g){
                my $pos = pos($line[0]);
                $plus_match_info[$pos] = 6; #loop
        }
        ############Line 2################
        while ($line[1] =~ m/[ATCGUN]/g){
                my $pos = pos($line[1]);
                $plus_match_info[$pos] = 1; #sRNA Match
        }
        while ($line[1] =~ m/\-/g){
                my $pos = pos($line[1]);
                $plus_match_info[$pos] = 5; #Gap
        }
        while ($line[1] =~ m/[atcgun]/g){
                my $pos = pos($line[1]);
                $plus_match_info[$pos] = 3; #non sRNA Match
        }
        while ($line[1] =~ m/[\.\\]/g){
                my $pos = pos($line[1]);
                $plus_match_info[$pos] = 7; #end line
        }
        ############Line 3################
        while ($line[2] =~ m/[ATCGUN]/g){
                my $pos = pos($line[2]);
                $minus_match_info[$pos] = 1; #sRNA Match
        }
        while ($line[2] =~ m/\-/g){
                my $pos = pos($line[2]);
                $minus_match_info[$pos] = 5; #Gap
        }
        while ($line[2] =~ m/[atcgun]/g){
                my $pos = pos($line[2]);
                $minus_match_info[$pos] = 3; #non sRNA Match
        }
        while ($line[2] =~ m/[\.\\]/g){
                my $pos = pos($line[2]);
                $minus_match_info[$pos] = 6; #loop
        }
        ############Line 4################
        while ($line[3] =~ m/[ATCGUN]/g){
                my $pos = pos($line[3]);
                $minus_match_info[$pos] = 2; #sRNA Mis-match
        }
        while ($line[3] =~ m/\-/g){
                my $pos = pos($line[3]);
                $minus_match_info[$pos] = 5; #Gap
        }
        while ($line[3] =~ m/[atcgun]/g){
                my $pos = pos($line[3]);
                $minus_match_info[$pos] = 4; #non sRNA Mis-match
        }
        while ($line[3] =~ m/[\.\\]/g){
                my $pos = pos($line[3]);
                $minus_match_info[$pos] = 6; #loop
        }
        ###################################
        foreach(@plus_match_info){
                $_ = 0 unless ($_);
                $plus = $plus.$_;
        }
        foreach(@minus_match_info){
                $_ = 0 unless ($_);
                $minus = $minus.$_;
        }
	my $overhang = 2;
       if ($plus =~ m/^([^12]*[345]{2})([12][125]+[12])([345]{2}[^12]*)$/){
                $picked_plus = $2;
		my $pre_s = index($plus, $picked_plus)+1;
		my $pre_rev_e = $pre_s-$overhang;
		my $i = $1 =~ tr/[056]//;
		my $m = substr($minus, 0, $pre_rev_e-1) =~ tr/[056]//;
		my $star = substr($minus, $pre_rev_e-1, length($picked_plus));
		my $shift_l = 0;
		if ($star =~ m/(5+)[12][125]+/){
			$shift_l = length($1);
		}
		$pre_rev_e = $_len-($pre_rev_e-$m-$shift_l)+1;
		$pre_s = $pre_s-$i;
		my $pre_e = index($plus, $picked_plus)+1+length($picked_plus)-1;
		my $pre_rev_s = $pre_e-$overhang;
		my $j = ($1.$2) =~ tr/[056]//;
		my $n = substr($minus, 0, $pre_rev_s) =~ tr/[056]//;
		my $pre_rev_s = $_len-($pre_rev_s-$n)+1;
		$pre_e = $pre_e-$j;
		return ($_len, $pre_s, $pre_e, $pre_rev_s, $pre_rev_e);
        }
        if ($minus =~ m/^([^12]*[345]{2})([12][125]+[12])([345]{2}[^12]*)$/){
                $picked_minus = $2;
                my $pre_e = index($minus, $picked_minus)+1;
                my $pre_rev_s = $pre_e+$overhang;
		my $i = $1 =~ tr/[056]//;
		my $m = substr($plus, 0, $pre_rev_s-1) =~ tr/[056]//;
		my $star = substr($plus, $pre_rev_s-1, length($picked_minus));
		my $shift_l = 0;
		if ($star =~ m/(5+)[12][125]+/){
			$shift_l = length($1);
		}
		$pre_rev_s = $pre_rev_s-$m-$shift_l;
                $pre_e = $_len-($pre_e-$i)+1;
                my $pre_s = index($minus, $picked_minus)+1+length($picked_minus)-1;
		my $pre_rev_e = $pre_s+$overhang;
		my $j = ($1.$2) =~ tr/[056]//;
		my $n = substr($plus, 0, $pre_rev_e) =~ tr/[056]//;
		$pre_rev_e = $pre_rev_e-$n;
                $pre_s = $_len-($pre_s-$j)+1;
		return ($_len, $pre_s, $pre_e, $pre_rev_s, $pre_rev_e);
	}
        return 0;
}

1;



