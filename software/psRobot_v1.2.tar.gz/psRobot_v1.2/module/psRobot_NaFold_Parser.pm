#!/usr/bin/perl

package NaFold_Parser;
use strict;

sub _PARSER{
	my ($line, $mismatch_min, $mismatch_max) = @_;
	my @line = split /\n/,$line;
	my $len  = (split /\_/,$line[2])[3];
	my $i;
	my $loop = 0;
	for ($i=6; $i<=$#line-4; $i=$i+8){
		my $judge = &Seek_Fine ($line[$i], $line[$i+1], $line[$i+2], $line[$i+3], $len, $mismatch_min, $mismatch_max);
		if ($judge == 1 and $loop == 0){ # one line no loop good structure
			return 1;
		}elsif ($judge == 1 and $loop == 1){ # multiple line no loop good structure
			return 2;
		}elsif ($judge == 2){ # multiple line loop on stem
			return 3;
		}elsif ($judge == 3 and $loop == 0){ # multiple line loop on loop, mature is on the first line
			return 4;
		}elsif ($judge == 4){ # Low mismatch smRNA
			return 5;
		}elsif ($judge == 0){
			$loop = 1;
		}
	}
	return 0;
}

sub Seek_Fine{
        my @line = @_;
        my @plus_match_info;
        my @minus_match_info;
        my $plus;
        my $minus;
        my $picked_plus;
        my $picked_minus;
	my $signal = 0;
        ############Line 1################
        while ($line[0] =~ m/[ATCGUN]/g){
                my $pos = pos($line[0]);
                $plus_match_info[$pos] = 2; #sRNA Mis-match
        }
        while ($line[0] =~ m/\-/g){
                my $pos = pos($line[0]);
                $plus_match_info[$pos] = 5; #Gap
        }
        while ($line[0] =~ m/[atcgun]/g){
                my $pos = pos($line[0]);
                $plus_match_info[$pos] = 4; #non sRNA Mis-match
        }
        while ($line[0] =~ m/[\.\\]/g){
                my $pos = pos($line[0]);
                $plus_match_info[$pos] = 6; #loop
        }
        ############Line 2################
        while ($line[1] =~ m/[ATCGUN]/g){
                my $pos = pos($line[1]);
                $plus_match_info[$pos] = 1; #sRNA Match
        }
        while ($line[1] =~ m/\-/g){
                my $pos = pos($line[1]);
                $plus_match_info[$pos] = 6; #loop
        }
        while ($line[1] =~ m/[atcgun]/g){
                my $pos = pos($line[1]);
                $plus_match_info[$pos] = 3; #non sRNA Match
        }
        while ($line[1] =~ m/[\.\\]/g){
                my $pos = pos($line[1]);
                $plus_match_info[$pos] = 7; #end line
        }
        ############Line 3################
        while ($line[2] =~ m/[ATCGUN]/g){
                my $pos = pos($line[2]);
                $minus_match_info[$pos] = 1; #sRNA Match
        }
        while ($line[2] =~ m/\-/g){
                my $pos = pos($line[2]);
                $minus_match_info[$pos] = 6; #loop
        }
        while ($line[2] =~ m/[atcgun]/g){
                my $pos = pos($line[2]);
                $minus_match_info[$pos] = 3; #non sRNA Match
        }
        while ($line[2] =~ m/[\.\\]/g){
                my $pos = pos($line[2]);
                $minus_match_info[$pos] = 6; #loop
        }
        ############Line 4################
        while ($line[3] =~ m/[ATCGUN]/g){
                my $pos = pos($line[3]);
                $minus_match_info[$pos] = 2; #sRNA Mis-match
        }
        while ($line[3] =~ m/\-/g){
                my $pos = pos($line[3]);
                $minus_match_info[$pos] = 5; #Gap
        }
        while ($line[3] =~ m/[atcgun]/g){
                my $pos = pos($line[3]);
                $minus_match_info[$pos] = 4; #non sRNA Mis-match
        }
        while ($line[3] =~ m/[\.\\]/g){
                my $pos = pos($line[3]);
                $minus_match_info[$pos] = 6; #loop
        }
        ###################################
        foreach(@plus_match_info){
                $_ = 0 unless ($_);
                $plus = $plus.$_;
        }
        foreach(@minus_match_info){
                $_ = 0 unless ($_);
                $minus = $minus.$_;
        }

#	print "$plus\n$minus\n"; #test the structure.

       if ($plus =~ m/^([^12]*[345]{2})([12][125]+[12])([345]{2}[^12]*)$/){
                $picked_plus = $2;
		my $i = $1 =~ tr/6/6/;
		my $j = $3 =~ tr/6/6/;
		return 0 if ($picked_plus =~ /[25]{3}/);
                $picked_minus = substr ($minus, index($plus, $picked_plus), length($picked_plus));
                my $a = $picked_plus =~ tr/5/5/;
                my $b = $picked_plus =~ tr/6/6/;
                my $c = $picked_minus =~ tr/6/6/;
                my $d = $picked_plus =~ tr/1/1/;
                my $e = $picked_plus =~ tr/2/2/;
		if ($line[4] == $d+$e and $b == 0 and $c == 0){
			if ($a+$e < $line[5]){
				$signal = 4; # Low mismatch one
			}elsif ($a+$e <= $line[6]){
				$signal = 2 if ($i > 0); # loop on stem
				$signal = 3 if ($j > 0); # loop on loop
				$signal = 1 if ($j == 0 and $i == 0); # no loop
			}
		}
        }
        if ($minus =~ m/^([^12]*[345]{2})([12][125]+[12])([345]{2}[^12]*)$/){
                $picked_minus = $2;
		my $i = $1 =~ tr/6/6/;
		my $j = $3 =~ tr/6/6/;
		return 0 if ($picked_minus =~ /[25]{3}/);
                $picked_plus = substr ($plus, index($minus, $picked_minus), length($picked_minus));
                my $a = $picked_minus =~ tr/5/5/;
                my $b = $picked_minus =~ tr/6/6/;
                my $c = $picked_plus =~ tr/6/6/;
                my $d = $picked_minus =~ tr/1/1/;
                my $e = $picked_minus =~ tr/2/2/;
                if ($line[4] == $d+$e and $b == 0 and $c == 0){
                        if ($a+$e < $line[5]){
				$signal = 4; # Low mismatch one
			}elsif ($a+$e <= $line[6]){
				$signal = 2 if ($i > 0); # loop on stem
				$signal = 3 if ($j > 0); # loop on loop
				$signal = 1 if ($j == 0 and $i == 0); # no loop
			}
                }
        }
        return $signal;
}

1;



