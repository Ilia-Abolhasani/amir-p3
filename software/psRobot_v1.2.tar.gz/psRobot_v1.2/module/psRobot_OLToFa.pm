#!/usr/bin/perl

package OLToFa;
use strict;

sub _1LToFa{
	my $_seq = shift;
	my $_fa;
	while (length($_seq) > 0){
		$_fa .= substr ($_seq, 0, 60)."\n";
		$_seq = substr ($_seq, 60);
	}
	return $_fa;
}

1;

