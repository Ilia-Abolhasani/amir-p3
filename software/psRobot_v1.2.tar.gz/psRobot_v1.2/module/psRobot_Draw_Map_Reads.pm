#!/usr/bin/perl

package Draw_Map_Reads;

use strict;

sub _Draw_Map_Reads{

my ($_In_File01, $_In_File02, $_Out_File) = @_;
my $reads_stt = 4;
open IN  ,  $_In_File01 or die $!;
open OUT , ">$_Out_File" or die $!;
while (<IN>){

chomp;
my @pre = split /\t/,$_;
my @reads;
my @highest;
my @mir;


open READS , "$_In_File02" or die $!;
open TMP1  , ">.tmp1" or die $!;
open TMP2  , ">.tmp2" or die $!;
while (<READS>){
	chomp;
	my @lines = split /\t/,$_;
	next if ($pre[1] ne $lines[1]);
	if ($pre[2]<=$lines[3] and $lines[4]<=$pre[3]){
		if ($pre[4] eq $lines[2]){
			my @tag = split /\_/,$lines[0];
			for my $i ($reads_stt..$#tag){
				push (@{$reads[$i-$reads_stt]}, $tag[$i]);
			}
			print TMP1 "$_\n";
		}else{
			print TMP2 "$_\n";
		}
	}
}
close READS;
close TMP1;
close TMP2;

next unless (@reads);

for my $i (0..$#reads){
	@{$reads[$i]} = sort {$a<=>$b} (@{$reads[$i]});
}

open TMP1 , ".tmp1" or die $!;
while (<TMP1>){
	chomp;
	my @lines = split /\t/,$_;
	my @tags  = split /\_/,$lines[0];
	for my $i ($reads_stt..$#tags){
		if ($tags[$i] eq $reads[$i-$reads_stt][$#{$reads[$i-$reads_stt]}] and @{$highest[$i-$reads_stt]}=''){
			@{$highest[$i-$reads_stt]} = @lines;
		}
	}
}
close TMP1;


open TMP1 , ".tmp1" or die $!;
while (<TMP1>){
	chomp;
	my @lines = split /\t/,$_;
	my @tags  = split /\_/,$lines[0];
	for my $i ($reads_stt..$#tags){
		if (($lines[3]>=$highest[$i-$reads_stt][3]-3 and $lines[3]<=$highest[$i-$reads_stt][3]+3) or ($lines[4]>=$highest[$i-$reads_stt][4]-3 and $lines[4]<=$highest[$i-$reads_stt][4]+3)){
			$mir[$i-$reads_stt] += $tags[$i];
		}
	}
}
close TMP1;


if ($pre[4] eq '-'){
	system `sort -rn -k5,5 -k4,4 .tmp1 > $$; mv $$ .tmp1`;
	system `sort -rn  -k5,5 -k4,4 .tmp2 > $$; mv $$ .tmp2`
}else{
	system `sort -n -k4,4 -k5,5 .tmp2 > $$; mv $$ .tmp2`;
}

print OUT "$pre[0] $pre[1]|$pre[2]|$pre[3]|$pre[4]\n$pre[5]\t@mir\n$pre[6]\n";

for my $i (0..$#highest){
	my $head = '*' x($highest[$i][3]-$pre[2]);
	my $end  = '*' x($pre[3]-$highest[$i][4]);
	if ($pre[4] eq '-'){
		my $temp = $head;
		$head = $end;
		$end  = $temp;
	}
	my $seq  = $highest[$i][5];
	my $read = $head.$seq.$end;
	my @tags = split /\_/,$highest[$i][0];
	my $loci = $tags[1];
	shift @tags; shift @tags; shift @tags;
	print OUT "$read\t$loci @tags\n";
}


open TMP1 , ".tmp1" or die $!;
while (<TMP1>){
	chomp;
	my @lines = split /\t/,$_;
	my @tags  = split /\_/,$lines[0];
	my $loci = $tags[1];
	my $head = '-' x($lines[3]-$pre[2]);
	my $end  = '-' x($pre[3]-$lines[4]);
	if ($pre[4] eq '-'){
		my $temp = $head;
		$head = $end;
		$end  = $temp;
	}
	my $seq  = $lines[5];
	my $read = $head.$seq.$end;
	shift @tags; shift @tags; shift @tags;
	print OUT "$read\t$loci @tags\n";
}
close TMP1;

open TMP2 , ".tmp2" or die $!;
while (<TMP2>){                                                                                                          
        chomp;                                                                                                           
        my @lines = split /\t/,$_;
	my @tags  = split /\_/,$lines[0];
	my $loci = $tags[1];                                                                                       
        my $head = '^' x($lines[3]-$pre[2]);                                                                             
        my $end  = '^' x($pre[3]-$lines[4]);                                                                             
        if ($pre[4] eq '-'){
                my $temp = $head;                                                                                        
                $head = $end;                                                                                            
                $end  = $temp;                                                                                           
        }
        my $seq  = $lines[5];                                                                                            
        $seq = reverse ($seq);
	my $read = $head.$seq.$end;
	shift @tags; shift @tags; shift @tags;
        print OUT "$read\t$loci @tags\n";
}
close TMP2;

}
close IN;
close OUT;
}

1;


