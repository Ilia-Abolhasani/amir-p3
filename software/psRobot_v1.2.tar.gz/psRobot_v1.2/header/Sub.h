/* Sub.h */

#ifndef _INC_SUB
#define _INC_SUB

Com_BP (char CBP_ch)
{
	switch (toupper(CBP_ch))
	{
		case 'A':
			return 'T';
		break;
		case 'T':
			return 'A';
		break;
		case 'G':
			return 'C';
		break;
		case 'C':
			return 'G';
		break;
		default:
			return CBP_ch;
		break;
	}
}

Front_Add (char FA_ch, char FA_array[], long FA_array_length)
{
	int i;	//if array is very long, this place it will use long replacing int to declare the variable
	for (i = FA_array_length-2; i >= 0; i--)
	{
		FA_array[i+1] = FA_array[i];
	}
	FA_array[0] = FA_ch;
}

Back_Add (char BA_array[], char BA_ch, long FA_array_length)
{
	int i;	//if array is very long, this place it will use long replacing int to declare the variable
	for (i = 0; i < FA_array_length-1; i++)
	{
		BA_array[i] = BA_array[i+1];
	}
	BA_array[FA_array_length-1] = BA_ch;
}

#endif //_INC_SUB
