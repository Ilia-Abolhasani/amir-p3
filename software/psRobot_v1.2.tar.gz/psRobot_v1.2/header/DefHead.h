/* DefHead.h */

#ifndef _INC_DEFHEAD
#define _INC_DEFHEAD

#include "Structure.h"

sr * defHead (void)
{
	sr *dh_head;
	if ((dh_head = (sr *) malloc (sizeof (sr))) == NULL)
	{
		printf ("cannot get the memory!");
		return (0);
	}
	dh_head->l = NULL;
	dh_head->a = dh_head->t = dh_head->g = dh_head->c = NULL;
	return (dh_head);
}

#endif //_INC_DEFHEAD

