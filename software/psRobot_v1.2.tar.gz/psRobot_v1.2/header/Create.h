/* Create.h */

#ifndef _INC_CREATE
#define _INC_CREATE

#include "Structure.h"

sr * create (sr *sr_head, int sr_len, char sr_seq[])
{
 sr *p, *s;
 int i;
 p = sr_head;
 for (i = 0; i < sr_len; i++)
 {
   switch (toupper(sr_seq[i]))
   {
     case 'A':
            if (p->a == NULL)
              {
                if ((s = (sr *) malloc (sizeof (sr))) == NULL)
                {
                  printf ("Cannot get the memory!");
                  return (0);
                }
                p->a = s;
                s->a = s->t = s->g = s->c = NULL;
                s->l = NULL;
              }
            else
              {
                s = p->a;
              }
     break;
     case 'T':
            if (p->t == NULL)
              {
                if ((s = (sr *) malloc (sizeof (sr))) == NULL)
                {
                  printf ("Cannot get the memory!");
                  return (0);
                }
                p->t = s;
                s->a = s->t = s->g = s->c = NULL;
                s->l = NULL;
              }
            else
              {
                s = p->t;
              }
     break;
     case 'G':
            if (p->g == NULL)
              {
                if ((s = (sr *) malloc (sizeof (sr))) == NULL)
                {
                  printf ("Cannot get the memory!");
                  return (0);
                }
                p->g = s;
                s->a = s->t = s->g = s->c = NULL;
                s->l = NULL;
              }
            else
              {
                s = p->g;
              }
     break;
     case 'C':
            if (p->c == NULL)
              {
                if ((s = (sr *) malloc (sizeof (sr))) == NULL)
                {
                  printf ("Cannot get the memory!");
                  return (0);
                }
                p->c = s;
                s->a = s->t = s->g = s->c = NULL;
                s->l = NULL;
              }
            else
              {
                s = p->c;
              }
     break;
     default:
		s = p;
		printf ("illegal seq: %c\n", sr_seq[i]);
     break;
   }
   p = s;
 }
 return (p);
}


#endif //_INC_CREATE
