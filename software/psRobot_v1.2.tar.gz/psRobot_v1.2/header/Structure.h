/* Structure.h */

#ifndef _INC_STRUCTURE
#define _INC_STRUCTURE

typedef struct srna
{
    char *l;
    struct srna *a;
    struct srna *t;
    struct srna *g;
    struct srna *c;
}sr;

#endif //_INC_STRUCTURE
