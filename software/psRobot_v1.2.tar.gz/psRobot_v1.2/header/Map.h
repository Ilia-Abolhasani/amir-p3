/* Map.h */

#ifndef _INC_MAP
#define _INC_MAP

#include "Structure.h"

map (FILE * map_fp, sr * map_head, char map_tag[], char map_chr[], long map_m, long map_m_r)
{
	sr * p, * s;
	p = map_head;
	int k=0;
	while (k < 40)
	{
		if (p->l != NULL)
		{
			if (map_m != 0)
			{
				fprintf (map_fp, "%s\t%s\t+\t%ld\t%ld\t", p->l, map_tag, map_m-39, map_m-39+k-1);
			}else{
				fprintf (map_fp, "%s\t%s\t-\t%ld\t%ld\t", p->l, map_tag, map_m_r+1-k+1, map_m_r+1);
			}
				int n;
				for (n = 0; n < k; n++)
				{
					fprintf (map_fp, "%c", map_chr[n]);
				}
				fprintf (map_fp, "\n");
		}
		switch (toupper(map_chr[k]))
		{
			case 'A':
				if (p->a)
				{
					s = p->a;
					p = s;
					k++;
				}else{
					k = 40;
				}
			break;
			case 'T':
				if (p->t)
				{
					s = p->t;
					p = s;
					k++;
				}else{
				    k = 40;
				}
			break;
	        case 'G':
				if (p->g)
				{
					s = p->g;
					p = s;
					k++;
				}else{
					k = 40;
				}
			break;
	        case 'C':
				if (p->c)
				{
					s = p->c;
					p = s;
					k++;
				}else{
					k = 40;
				}
			break;
			default:
//				printf ("illegal seq2: %c\n", map_chr[k]);
				k =40;
			break;
		}
	}
}

#endif //_INC_MAP
