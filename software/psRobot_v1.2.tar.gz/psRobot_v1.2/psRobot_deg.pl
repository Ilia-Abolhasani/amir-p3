#!/usr/bin/perl

use strict;

if (@ARGV != 4 or (@ARGV == 1 and ($ARGV[0] eq "-h") or ($ARGV[0] eq "-v"))){
        print "psRobot_deg version 1.2\n";
        print "psRobot_deg is designed to identify degradome data supported small RNA targets.\n\n";
        print "[usage]:\npsRobot_deg <degradome_data> <target_sequences> <smRNA-target.gTP> <output>\n\n";
        print "<degradome_data> is the first input file which contains degradome sequences in tab-delimited (tsv) format.\n";
        print "<Seq>\t<Counts> (Don't include this row.)\n";
        print "TGACAGAAGAGAGTGAGCAC\t108\n";
        print "TCGCTTGGTGCAGATCGGGAC\t373\n";
        print "TTGACAGAAGAGAGTGAGCAC\t10\n";
        print "TGAAGCTGCCAGCATGATCTGA\t2\n";
        print "GGCGGATGTAGCCAAGTGGA\t203\n";
        print ".\t.\n";
        print ".\t.\n";
        print ".\t.\n\n";
        print "<target_sequences> is the second input file which contains the target sequences in fasta format as prediction library and must be identical to <target> file in psRobot_tar.:\n\n";
        print "<smRNA-target.gTP> is the third input file which could be the direct output file of psRobot_tar.\n\n";
	print "<output> is the output file containing the degradome data supported small RNA targets\n";
        print ">ath_miR156a\tScore: 1.0\tDeg: 285:2378:285:1635\tAT1G27370.1 | Symbols: SPL10\n";
        print "\nQuery:          1 TGACAGAAGAGAGTGAGCAC 20\n";
        print "                  |||||||||||||*||||||\n";
        print "Sbjct:       2387 ACTGTCTTCTCTCTCTCGTG 2368\n";
        print "                  |  |||||||||     ||--------------------------------2\n";
        print "                  |  |||||||||     |---------------------------------1\n";
        print "                  |  |||||||||---------------------------------------1\n";
	print "                  |  ||||||||----------------------------------------3\n";
	print "                  |  |||||||-----------------------------------------285\n";
	print "                  |  ||||||------------------------------------------152\n";
	print "                  |  |||||-------------------------------------------8\n";
	print "                  |  ||||--------------------------------------------6\n";
	print "                  |  |||---------------------------------------------1\n";
	print "                  |  ||----------------------------------------------2\n";
        print "                  |  |-----------------------------------------------3\n";
	print "                  |--------------------------------------------------1\n\n";
	print "Written by Wu Hua-Jun\nPowered by omicslab\n";
	die "\n";
}

my $tmp = time(); # temporary file name.
############################## Format degradome data ##############################

my $deg_seq_order;

open DEG  ,  $ARGV[0] or die $!;
open FORMAT  ,  ">$tmp.format" or die $!;
while (<DEG>){
	next if (/^#/);
	chomp;
	my @lines = split /\t/,$_;
	$deg_seq_order++;
	my $deg_seq_name = "deg".$deg_seq_order."_$lines[1]";
	$deg_seq_name =~ s///g;
	print FORMAT "$deg_seq_name\t$lines[0]\n";
}
close FORMAT;
close DEG;

###################################################################################

############################# Mapping #############################################
`$lib_dir/psRobot_map $tmp.format $ARGV[1] $tmp.map`;
###################################################################################

############################# generate position degradome reads ###################

my $prev_tag;
my $prev_max;
my %prev_deg;
my $prev_sum;

open MAP  , "$tmp.map" or die $!;
open DEG  , ">$tmp.deg" or die $!;
while (<MAP>){
	chomp;
	my @lines = split /\t/,$_;
	next unless ($lines[2] eq '+');
	my $curr_pos_deg = (split /\_/,$lines[0])[1];
	$lines[1] =~ s/ .*//g;
	if ($prev_tag ne $lines[1] and $prev_tag){
		foreach (sort {$a<=>$b} keys %prev_deg){
			print DEG "$prev_tag\t$prev_sum\t$prev_max\t$_\t$prev_deg{$_}\n";
		}
		undef %prev_deg;
		$prev_max = 0;
		$prev_sum = 0;
	}
	$prev_deg{$lines[3]} += $curr_pos_deg;
	$prev_tag = $lines[1];
	$prev_sum += $curr_pos_deg;
	$prev_max = $prev_deg{$lines[3]} if ($prev_max < $prev_deg{$lines[3]});
}
foreach (sort {$a<=>$b} keys %prev_deg){
	print DEG "$prev_tag\t$prev_sum\t$prev_max\t$_\t$prev_deg{$_}\n";
}
close MAP;
close DEG;

###################################################################################

############################# Link degradome data #################################

my %deg_reads;
my %deg_sum;
my %deg_max;

open DEG  ,  "$tmp.deg" or die $!;
while (<DEG>){
	chomp;
	my @lines = split /\t/,$_;
	$deg_reads{$lines[0]}{$lines[3]} = $lines[4];
	$deg_sum{$lines[0]}              = $lines[1];
	$deg_max{$lines[0]}              = $lines[2];
}
close DEG;

open OUT  , ">$ARGV[3]" or die $!;
open TAR  ,  $ARGV[2] or die $!;
$/ = ">";
while (<TAR>){
	chomp;
	next if ($. == 1);
	my @blocks  = split /\n/,$_;
	my @tag     = split /\t/,$blocks[0];
	my $gid     = (split / /,$tag[2])[0];
	$blocks[4]  =~ m/(Sbjct:\s+(\d+) \S+) (\d+)/;
	my $stt = $3; my $end = $2;
	my $blank_seq = $1;
	my $blank_len = length($1);
	my $tar_deg_max;
	my $tar_deg_max_pos;
	my @sig;
	for my $i ($stt..$end){
		if ($deg_reads{$gid}{$i}){
			my $sub_len = $i-$stt+1;
			my $shift_seq = substr($blank_seq, -$sub_len);
			my $shift = $shift_seq =~ tr/-/-/;
			my $blank = ' 'x($blank_len-$sub_len-$shift);
			my $dash  = '-'x($sub_len+30+$shift);
			my $signiture = "$blank|$dash$deg_reads{$gid}{$i}";
			foreach my $j (@sig){
				substr($j, length($blank), 1) = '|';
			}
			push (@sig, $signiture);
		}
		if ($tar_deg_max < $deg_reads{$gid}{$i}){
			$tar_deg_max = $deg_reads{$gid}{$i};
			$tar_deg_max_pos = $i;
		}
	}
	if ($tar_deg_max){
		print OUT ">$tag[0]\t$tag[1]\tDeg: $tar_deg_max:$tar_deg_max_pos:$deg_max{$gid}:$deg_sum{$gid}\t$tag[2]\n\n$blocks[2]\n$blocks[3]\n$blocks[4]\n";
		print OUT join("\n", @sig)."\n\n";
	}
}
$/ = "\n";
close TAR;
close OUT;

unlink "$tmp.format";
unlink "$tmp.map";
unlink "$tmp.deg";
###################################################################################


