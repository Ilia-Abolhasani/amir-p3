#!/usr/bin/perl

use strict;

my $tmp = time();

if (@ARGV != 3 or (@ARGV == 1 and ($ARGV[0] eq "-h") or ($ARGV[0] eq "-v"))){
	print "psRobot_map version 1.2\n";
	print "psRobot_map is designed to find all the perfect matched locations of short sequences in reference sequences.\n\n";
	print "[usage]:\npsRobot_map <short_sequences> <reference_sequences> <output>\n\n";
	print "<short_sequences> is the first input file which contains the short sequences in tab-delimited (tsv) format.\n";
	print "<ID>\t<SEQ> (Don't include this row.)\n";
	print "SrID001\tTGACAGAAGAGAGTGAGCAC\n";
	print "SrID002\tTCGCTTGGTGCAGATCGGGAC\n";
	print "SrID003\tTTGACAGAAGAGAGTGAGCAC\n";
	print "SrID004\tTGAAGCTGCCAGCATGATCTGA\n";
	print "SrID005\tGGCGGATGTAGCCAAGTGGA\n";
	print ".\t.\n";
	print ".\t.\n";
	print ".\t.\n\n";
	print "<reference_sequences> is the second input file which contains the reference sequences in fasta format:\n\n";
	print "<output> is the output file containing the mapping results:\n";
	print "ID\tref\tstrand\tstart\tend\tseq\n";
	print "SrID003\tref01\t+\t28\t48\tTTGACAGAAGAGAGTGAGCAC\n";
	print "SrID001\tref01\t+\t29\t48\tTGACAGAAGAGAGTGAGCAC\n";
	print "SrID001\tref01\t+\t60\t79\tTGACAGAAGAGAGTGAGCAC\n";
	print ".\t.\t.\t.\t.\t.\n";
	print ".\t.\t.\t.\t.\t.\n";
	print ".\t.\t.\t.\t.\t.\n\n";
	print "Written by Wu Hua-Jun\nPowered by omicslab\n";
	die "\n";
}

open IN   ,  $ARGV[1] or die $!;
open OUT  ,  "> $ARGV[1]_$tmp" or die $!;

while(<IN>){
	chomp;
	if ($. == 1 and /^>(\S+)/){
		print OUT "$1\t";
		next;
	}
	if (/^>(.*)$/){
		print OUT "\n$1\t";
	}else{
		print OUT $_;
	}
}
print OUT "\n";

close IN;
close OUT;

`$lib_dir/psR_map_untreated $ARGV[0] $ARGV[1]_$tmp $ARGV[2]`;

unlink "$ARGV[1]_$tmp";


