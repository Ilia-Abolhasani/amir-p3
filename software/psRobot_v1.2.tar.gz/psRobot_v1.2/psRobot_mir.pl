#!/usr/bin/perl

use strict;
use psRobot_OLToFa;
use psRobot_Auto_NaFold;
use psRobot_Extract_Seq;
use psRobot_NaFold_Parser_plus;
use psRobot_SmRNA_Cluster;
use psRobot_Star_Pos;
use psRobot_Draw_Map_Reads;
my $file01 = "smRNA";
my $file02 = "kmiRNA";
my $file03 = "genome";

############################### Param (* ** ***) ##########################
my $ref_reads	      = 2;   # Pick reads >= 2 *
my $ref_loci	      = 20;  # 0: no restriction **
my $ref_cluster_gap   = 200; # inter cluster gap ***
my $ref_cluster_reads = 10;  # minimal cluster's total reads
my $ref_smrc_len      = 300; # Maximal smRNA cluster length ***
my $ref_mature_reads  = 10;  # Minimal mature reads (the highest one is treated as mature miRNA)
my $ref_mismatch_min  = 1;   # Minimal mismatch nt
my $ref_mismatch_max  = 5;   # Maximal mismatch nt
my $ref_long_loop     = "F"; # Not select long loop miRNA 
###########################################################################

############################### Input param ###############################
if (@ARGV == 0 or (@ARGV == 1 and $ARGV[0] eq "-h")){
	print "psRobot_mir version 1.2\n";
	print "psRobot_mir is designed to find potential miRNAs or small hairpin RNAs (shRNAs) from high throughput sequencing data.\n\n";
	print "psRobot_mir arguments: \n\n";
	print "  -s    input file name: smRNA sequencing data in tab-delimited (tsv) format\n";
	print "    default = smRNA\n";
	print "  -k    input file name: known miRNA position file in GFF3 format\n";
	print "        This file is needed only if one wants to exclude known miRNAs from prediction results.\n";
	print "    default = kmiRNA\n";
	print "  -g    input file name: reference genome in FASTA format\n";
	print "    default = genome\n";
	print "  -r    clone reads selection: minimal smRNA clone reads\n";
	print "    default = 2\n";
	print "  -l    loci  selection: the maximal number of smRNA mapping locations in reference genome\n";
	print "    default = 20\n";
	print "  -cg   minimal number of nucleartides between adjacent smRNA clusters\n";
	print "    default = 200\n";
	print "  -cl   maximal length limitation of smRNA clusters selected to predict stem-loop precursors\n";
	print "    default = 300\n";
	print "  -cr   clusters with minimal total clone reads will be selected to predict stem-loop precursors\n";
	print "    default = 10\n";
	print "  -mr   clusters with maximal clone reads higher than this number will be selected to predict stem-loop precursors\n";
	print "    default = 10\n";
	print "  -mml  minimal number of mismatches in supposed miRNA mature region\n";
	print "    default = 1\n";
	print "  -mmh  maximal number of mismatches in supposed miRNA mature region\n";
	print "    default = 5\n";
	print "  -ll   retain long loop miRNA [T/F]\n";
	print "    default = F\n";
	print "\nWritten by Wu Hua-Jun\nPowered by omicslab\n";
	die   "\n";
}

(@ARGV%2 == 0) or die "ERROR: Missing parameter.\n";
my $par;
for ($par=0; $par<$#ARGV; $par+=2){
	if     ($ARGV[$par] eq "-s"){         # Input file: smRNA sequencing data
		$file01 = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-k"){         # Input file: Known miRNA tff3 file
		$file02 = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-g"){         # Input file: ref genome
		$file03 = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-r"){
		$ref_reads = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-l"){
		$ref_loci  = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-cg"){
		$ref_cluster_gap = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-cl"){
		$ref_smrc_len = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-cr"){
		$ref_cluster_reads = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-mr"){
		$ref_mature_reads = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-mml"){
		$ref_mismatch_min = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-mmh"){
		$ref_mismatch_max = $ARGV[$par+1];
	}elsif ($ARGV[$par] eq "-ll"){
		$ref_long_loop = $ARGV[$par+1];
	}else{
		die "Command line help: psRobot_mir -h\n";
	}
}

unless (-e $file02){
	open KMIRNA , ">$file02" or die $!;
	close KMIRNA;
}
###########################################################################
print "Pre-process...\n";
###########################################################################
my $srna_id;

open IN  ,  $file01 or die $!;
open OUT , ">SAMP.sRNA" or die $!;
open OUT1, ">SAMP-smap.sRNA" or die $!;
while (<IN>){
	chomp;
	my @lines     = split /\t/,$_;
	my $len       = length($lines[0]);
	my $seq       = shift @lines;
	my $max_reads = (sort {$a<=>$b} @lines)[$#lines];
	next if ($max_reads < $ref_reads);
	$srna_id++;
	print OUT  "Sr$srna_id"."_$len"."_$max_reads\t$seq\n";
	unshift (@lines, "Sr$srna_id");
	print OUT1 join("\t", @lines)."\n";
}
close IN;
close OUT;
close OUT1;
###########################################################################
print "smRNA mapping...\n";
############################### Mapping ###################################
`$lib_dir/psRobot_map SAMP.sRNA $file03 SAMP-mapping`;
###########################################################################
print "Format smRNA...\n";
############################### Format smRNA ##############################
my %count;
my %srid;
open IN   ,   "<SAMP-mapping" or die $!;
while (<IN>){
	chomp;
	my @line = split /\t/,$_;
	$count{$line[5]} ++;
}
close IN;

open OUT  ,   ">SAMP-mapping.fmt" or die $!;
open IN   ,   "<SAMP-mapping" or die $!;
while (<IN>){
	chomp;
	my @line = split /\t/,$_;
	my @tag = split /\_/,$line[0];
	my $id   = shift @tag;
	if (not exists $srid{$id}){
		$srid{$id} = 1;
	}else{
		$srid{$id}++;
	}
	my $chr = $line[1];
	print OUT "$id"."_$count{$line[5]}_$srid{$id}";
	print OUT "_".join('_',@tag)."\t$chr\t$line[2]\t$line[3]\t$line[4]\t$line[5]\n";
}
close OUT;

#`mv SAMP-mapping.fmt SAMP-mapping`;
unlink("SAMP-mapping");
rename("SAMP-mapping.fmt", "SAMP-mapping") or die $!;
###########################################################################
###########################################################################
print "PreSelect smRNA...\n";
################## PreSelect smRNA ########################################
open IN  , "<SAMP-mapping" or die $!;
open OUT , ">SAMP-mapping-RF" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	my @reads = split /\_/,$lines[0];
	shift @reads; my $loci = shift @reads; shift @reads; shift @reads;
	my $reads;
	map {$reads += $_} @reads;
	if ($reads >= $ref_reads and ($loci <= $ref_loci or $ref_loci == 0) ){
		print OUT "$_\n";
	}
}
close IN;
close OUT;
######################################################################
print "Split Plus and Minus matched smRNA...\n";
################# Split Plus and Minus matched smRNA ################
#`awk '\$3=="+"' SAMP-mapping-RF > SAMP-mapping-RF-Plus`;
#`awk '\$3=="-"' SAMP-mapping-RF > SAMP-mapping-RF-Minus`;
#`cat SAMP-mapping-RF-Plus SAMP-mapping-RF-Minus > SAMP-mapping-RF`;
open OUT , ">SAMP-mapping-RF-Plus-Minus" or die $!;
open IN  ,  "SAMP-mapping-RF" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	print OUT "$_\n" if ($lines[2] eq '+');
}
close IN;
open IN  ,  "SAMP-mapping-RF" or die $!;
while (<IN>){
        chomp;
        my @lines = split /\t/,$_;
        print OUT "$_\n" if ($lines[2] eq '-');
}
close IN;
close OUT;
unlink ("SAMP-mapping-RF");
rename ("SAMP-mapping-RF-Plus-Minus", "SAMP-mapping-RF") or die $!;
#######################################################################
print "smRNA cluster identification...\n";
################# smRNA cluster identification ######################
&SmRNA_Cluster::_SmRNA_Cluster("SAMP-mapping-RF", "SAMP-RF-smRNACluster", $ref_cluster_gap, $ref_loci, $ref_cluster_reads, $ref_reads);
#########################################################################
print "smRNA cluster matched known miRNA region...\n";
################## smRNA cluster matched known miRNA region #############
my $position = 0;
my $judge = 0;

open IN  ,  "SAMP-RF-smRNACluster" or die $!;
open OUT ,  ">SAMP-RF-smRNACluster.miRNA" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	open MIR  ,  $file02 or die $!;
	while (<MIR>){
		chomp;
		my @mir = split /\t/,$_;
		my @ol;
		push (@ol, $mir[3]);
		push (@ol, $mir[4]);
		push (@ol, $lines[4]);
		push (@ol, $lines[5]);
		@ol = sort {$a<=>$b} @ol;
		if ($mir[0] eq $lines[3] and $mir[6] eq $lines[6] and (($ol[3]-$ol[0]) <= ($mir[4]-$mir[3]+1+$lines[5]-$lines[4]+1+100))){
			print OUT join("\t",@lines)."\t$mir[8]\n";
			$judge = 1;
			last;
		}
	}
	close MIR;
	print OUT join("\t",@lines)."\tNoMIR\n" unless ($judge);
	$judge = 0;
}
close IN;
close OUT;
#################################################################################
print "Precursor seq extraction...\n";
################## Precursor seq extraction #####################################
my %chr;
my @up = (10,100,10);
my @down = (100,10,10);

open CHR  ,  $file03 or die $!;
$/ = ">";
while (<CHR>){
	chomp;
	next if ($. == 1);
	my @lines = split /\n/,$_;
	my $tag   = shift @lines;
	$tag =~ s/\s.*//g;
	$chr{$tag} = join("", @lines);
}
$/ = "\n";
close CHR;

open OUT  , ">Candidate_Pre.fa" or die $!;
open  IN  , "SAMP-RF-smRNACluster.miRNA" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	next unless ($lines[10] eq "NoMIR");
	my @col01 = split /\_/,$lines[0];
	my $smrc_len = $col01[0];
	my @reads = split /\_/,$lines[7];
	shift @reads; shift @reads; shift @reads; shift @reads;
	@reads = sort {$a <=> $b} @reads;
	next unless ($smrc_len<=$ref_smrc_len and ($reads[$#reads]>=$ref_mature_reads));
	my $chr_len = length($chr{$lines[3]});
	my $seq;
	my $start = $lines[4];
	my $uc_start = $lines[8];
	my $end = $lines[5];
	my $uc_end = $lines[9];
	my $strand = $lines[6];
	my $data_seq = $chr{$lines[3]};
	for my $i (0..$#up){
		my $real_stt; my $real_end; my $up; my $dn;
		($seq,$real_stt,$real_end) = &Extract_Seq::_Extract_Seq($start, $end, $uc_start, $uc_end, $strand, $data_seq, $up[$i], $down[$i]);
		$seq = &OLToFa::_1LToFa($seq);
		if ($strand eq '+'){
			$up = $start-$real_stt;
			$dn = $real_end-$end;
		}else{
			$up = $real_end-$end;
			$dn = $start-$real_stt;
		}
		print OUT ">$lines[7]||$up||$dn\n$seq";
	}
}
close IN;
close OUT;
###################################################################################
print "Split fasta and run nafold...\n";
#################### Split fasta and run nafold ###################################
unlink "Candidate_Pre.fa.out";
my $num = 20000;
my $seq_num = 0;
open OUT , ">.tmp" or die $!;
open  IN , "<Candidate_Pre.fa" or die $!;
while (<IN>){
	chomp;
	$seq_num++ if (/^>/);
	if ($seq_num == $num+1){
		$seq_num = 1;
		close OUT;
		print "Round...\n";
		&Auto_NaFold::_NaFold(".tmp");
		`cat .tmp.out >> Candidate_Pre.fa.out`;
		open OUT , ">.tmp" or die $!;
	}
	print OUT "$_\n";
}
close IN;
close OUT;
&Auto_NaFold::_NaFold(".tmp");
`cat .tmp.out >> Candidate_Pre.fa.out`;

###############################################################################
print "Pick good structure...\n";
################### Pick good structure #######################################
open OUT,">Candidate_Pre_GoodStruc" or die $!;
open IN ,"Candidate_Pre.fa.out" or die $!;
$/ = "\nSequence";
while (<IN>){
	chomp;
	my @line = split /\n/,$_;
	my $i;
	my $tag = (split /\s+/,$line[2])[6];
	$tag =~ s/\|\|/\t/g;
	my $len = (split /\_/,$line[2])[1];
	my @judge = &NaFold_Parser::_PARSER($_, $ref_mismatch_min, $ref_mismatch_max);
	if ($judge[0]){
		$judge[1] = $judge[1]-10;
		$judge[2] = $judge[2]+10;
		print OUT "$tag\t$judge[1]\t$judge[2]\n";
	}
}
$/ = "\n";
close IN;
close OUT;
################################################################################
print "Fine Stem-Loop Mapping...\n";
############################### Fine Stem-Loop Mapping #########################
{
my %smr_clust;
open IN , "SAMP-RF-smRNACluster.miRNA" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/, $_;
	$smr_clust{$lines[7]} = "$lines[3]\t$lines[4]\t$lines[5]\t$lines[6]\t$lines[8]\t$lines[9]";
}
close IN;

open IN , "Candidate_Pre_GoodStruc" or die $!;
open OUT, ">Candidate_Pre_GoodStruc.list" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/, $_;
	my @smr_clust = split /\t/, $smr_clust{$lines[0]};
	my $clust_up; my $clust_down;
	if ($smr_clust[3] eq '+'){
		$clust_up    = $smr_clust[4]-($smr_clust[1]-$lines[1]+$lines[3])+1;
		$clust_down  = ($smr_clust[1]-$lines[1]+$lines[4])-$smr_clust[5]+1;
	}else{
		$clust_up    = $smr_clust[2]+$lines[1]-$lines[3]-$smr_clust[5]+1;
		$clust_down  = $smr_clust[4]-($smr_clust[2]+$lines[1]-$lines[4])+1;
	}
	print OUT "$lines[0]\t$smr_clust[0]\t$clust_up\t$clust_down\t$smr_clust[3]\t$smr_clust[4]\t$smr_clust[5]\n";
}
close IN;
close OUT;
}

@up   = (0, 10, 0, 10);
@down = (0, 0, 10, 10);
unlink "Final_PreDict_miRNA.Struc";

open  IN  ,  "Candidate_Pre_GoodStruc.list" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	my $seq;
	my $start = $lines[5];
	my $uc_start = $lines[5];
	my $end = $lines[6];
	my $uc_end = $lines[6];
	my $strand = $lines[4];
	my $data_seq = $chr{$lines[1]};
	my $id_output = $lines[0];
	
	open OUT  , ">.tmp01" or die $!;
	for my $i (0..$#up){
		my $up   = $up[$i]+$lines[2];
		my $down = $down[$i]+$lines[3];
		($seq,,) = &Extract_Seq::_Extract_Seq($start, $end, $uc_start, $uc_end, $strand, $data_seq, $up, $down);
		$seq = &OLToFa::_1LToFa($seq);
		print OUT ">$id_output||$up||$down\n$seq";
	}
	close OUT;
	&Auto_NaFold::_NaFold(".tmp01");

	my $fine_struc;
	my $low_energy;
	open NF , ".tmp01.out" or die $!;
	$/ = "\nSequence";
	while (<NF>){
		chomp;
		my @line = split /\n/,$_;
		my $i;
		my $len = (split /\_/,$line[2])[1];
		my $Fold_len = (split /\s+/,$line[2])[4];
		my $dg = (split /\s+/,$line[3])[3];
		my @judge = &NaFold_Parser::_PARSER($_, $ref_mismatch_min, $ref_mismatch_max);
		if ($judge[0] == 1 or ($ref_long_loop eq "T" and $judge[0] == 4)){
			if ($low_energy > $dg/$Fold_len){
				$low_energy = $dg/$Fold_len;
				$fine_struc = "Sequence$_\n";
			}
		}
	}
	$/ = "\n";
	close NF;
	open OUT,">>Final_PreDict_miRNA.Struc" or die $!;
		print OUT "\n";
		print OUT "$fine_struc" if ($fine_struc);
	close OUT;

}
close IN;

{
my %low_energy;
my %fine_struc;
open IN  ,  "Final_PreDict_miRNA.Struc" or die $!;
$/ = "\nSequence";
while (<IN>){
	chomp;
	my @lines = split /\n/,$_;
	my $tag  = (split /\s+/,$lines[2])[6];
	my $tag_uniq = (split /\|\|/,$tag)[0];
	my $Fold_len = (split /\s+/,$lines[2])[4];
	my $dg = (split /\s+/,$lines[3])[3];
	if ($Fold_len != 0 and $low_energy{$tag_uniq} > $dg/$Fold_len){
		$low_energy{$tag_uniq} = $dg/$Fold_len;
		$fine_struc{$tag_uniq} = "Sequence$_\n";
	}
}
$/ = "\n";
close IN;
open OUT  , ">Final_PreDict_miRNA.Struc" or die $!;
print OUT "\n";
foreach (keys %fine_struc){
	print OUT "$fine_struc{$_}";
}
close OUT;
}
######################################################################
print "Delete inter file...\n";
################# Delete inter file ##################################
unlink "SAMP-mapping-RF-Minus", "SAMP-mapping-RF-Plus", "SAMP-RF-smRNACluster";
unlink "Candidate_Pre.fa.out", "Candidate_Pre_GoodStruc.list";
unlink "fort.4", "mfold.log";
unlink glob ".tmp*";
###########################################################################
print "Extract exact up-down sequences...\n";
################## Extract exact up-down sequences #######################
#`grep "Folding" Final_PreDict_miRNA.Struc |sed "s/  */\t/g" |cut -f7 |sed "s/||/\t/g" > Final_PreDict_miRNA.list`;
#`awk -F"\t" 'NR==FNR {a[\$1]=\$2"\t"\$3} NR>FNR && (\$8 in a) {print \$8"\t"\$4"\t"\$9"\t"\$10"\t"\$7"\t"a[\$8]}' Final_PreDict_miRNA.list SAMP-RF-smRNACluster.miRNA > .t0001; mv .t0001 Final_PreDict_miRNA.list`;
my %link;
open IN  ,  "Final_PreDict_miRNA.Struc" or die $!;
while (<IN>){
	chomp;
	if (/^Folding bases/){
		my @lines = split /\s+/,$_;
		my @id    = split /\|\|/, $lines[6];
		$link{$id[0]} = "$id[1]\t$id[2]";
	}
}
close IN;

open IN  ,  "SAMP-RF-smRNACluster.miRNA" or die $!;
open OUT , ">Final_PreDict_miRNA.list" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	if (exists $link{$lines[7]}){
		print OUT "$lines[7]\t$lines[3]\t$lines[8]\t$lines[9]\t$lines[6]\t$link{$lines[7]}\n";
	}
}
close IN;
close OUT;


open OUT  , ">Final_PreDict_miRNA.1ln" or die $!;
open  IN  , "Final_PreDict_miRNA.list" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	my $start = my $uc_start = $lines[2];
	my $end = my $uc_end = $lines[3];
	my $strand = $lines[4];
	my $data_seq = $chr{$lines[1]};
	my $up = $lines[5];
	my $down = $lines[6];

	my ($seq, $real_start, $real_end) = &Extract_Seq::_Extract_Seq($start, $end, $uc_start, $uc_end, $strand, $data_seq, $up, $down);

	print OUT ">$lines[0]\t$lines[1]\t$real_start\t$real_end\t$strand\t$seq\n";

}
close IN;
close OUT;
##############################################################################
print "Get miRNA star information...\n";
#################### Get miRNA star information ##############################
#`cut -f1,6 Final_PreDict_miRNA.1ln |sed "s/>//g" > Final_PreDict_miRNA_Ref.1ln`;
open IN  ,  "Final_PreDict_miRNA.1ln" or die $!;
open OUT , ">Final_PreDict_miRNA_Ref.1ln" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	$lines[0] =~ s/>//g;
	print OUT "$lines[0]\t$lines[5]\n";
}
close IN;
close OUT;

#`cut -f1,6 SAMP-mapping-RF > SAMP-Loci-Reads`;
open IN  ,  "SAMP-mapping-RF" or die $!;
open OUT , ">SAMP-Loci-Reads" or die $!;
while (<IN>){
        chomp;
        my @lines = split /\t/,$_;
        print OUT "$lines[0]\t$lines[5]\n";
}
close IN;
close OUT;

`$lib_dir/psR_map_untreated SAMP-Loci-Reads Final_PreDict_miRNA_Ref.1ln Final_PreDict_miRNA_Ref.Mapped`;

#`awk '\$3=="+"' Final_PreDict_miRNA_Ref.Mapped > .t0001; mv .t0001 Final_PreDict_miRNA_Ref.Mapped`;
open IN  ,  "Final_PreDict_miRNA_Ref.Mapped" or die $!;
open OUT , ">.t0001" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	if ($lines[2] eq '+'){
		print OUT "$_\n";
	}
}
close IN;
close OUT;
unlink ("Final_PreDict_miRNA_Ref.Mapped");
rename (".t0001", "Final_PreDict_miRNA_Ref.Mapped") or die $!;

&SmRNA_Cluster::_SmRNA_Cluster("Final_PreDict_miRNA_Ref.Mapped", "Final_PreDict_miRNA_Ref.cluster", 0, 0, 1, 1);

my %star_s;
my %star_e;
my %ori_seq_id;
my %reads_pos;
my %star_reads;
my %star_id;
my %mature_info;
my %mature_seq;

open IN , "Final_PreDict_miRNA.Struc" or die $!;
$/ = "\nSequence";
 while (<IN>)
 {
	chomp;
	my @pos = &Star_Pos::_POS($_);
	my $id  = shift @pos;
	$star_s{$id} = $pos[3];
	$star_e{$id} = $pos[4];
 }
$/ = "\n";
close IN;

open IN , "Final_PreDict_miRNA_Ref.cluster" or die $!;
while (<IN>){
	chomp;
	next if ($. == 1);
	my @lines = (split /\t/)[3,4,5];
	push @{$reads_pos{$lines[0]}}, $lines[1];
	push @{$reads_pos{$lines[0]}}, $lines[2];
}
close IN;

open IN , "Final_PreDict_miRNA_Ref.Mapped" or die $!;
while (<IN>){
	chomp;
	my @lines = (split /\t/);
	push @{$star_reads{$lines[1]}}, $lines[3];
	push @{$star_reads{$lines[1]}}, $lines[4];
	push @{$star_id{$lines[1]}}, ($lines[0]."\t".$lines[5]);
}
close IN;

open IN , "Final_PreDict_miRNA.1ln" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/;
	$lines[0] =~ s/>//g;
	$mature_info{$lines[0]} = "$lines[1]:$lines[2]:$lines[3]:$lines[4]\t$lines[5]";
	$lines[5] =~ s/[a-z]//g;
	$mature_seq{$lines[0]}  = $lines[5];
}
close IN;

open IN , "SAMP-mapping-RF" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/;
	$ori_seq_id{"$lines[1]:$lines[2]:$lines[3]:$lines[4]"} = $lines[0];
}
close IN;

open OUT, ">Final_PreDict_miRNA.StarInfo" or die $!;
foreach (keys %reads_pos){
	my $clus_num = @{$reads_pos{$_}}/2;
	my $i;
	my $fine_star_id;
	my $fine_star_ovlp;
	my $fine_star_rang;
	my $star_stt;
	my $star_end;
	for ($i=0; $i<$#{$star_reads{$_}}; $i+=2){
		my @tmp = ($star_reads{$_}[$i], $star_reads{$_}[$i+1], $star_s{$_}, $star_e{$_});
		@tmp = sort {$a <=> $b} @tmp;
		my $len01 = $star_reads{$_}[$i+1]-$star_reads{$_}[$i]+1;
		my $len02 = $star_e{$_}-$star_s{$_}+1;
		if ( ($tmp[3]-$tmp[0]+1 < $len01+$len02) and ($tmp[2]-$tmp[1]+1 >= 15) and abs($star_reads{$_}[$i]-$star_s{$_}) <= 3 and abs($star_reads{$_}[$i+1]-$star_e{$_}) <= 3 ){
			if (($tmp[2]-$tmp[1]+1 > $fine_star_ovlp) or (($tmp[2]-$tmp[1]+1 == $fine_star_ovlp) and ($tmp[3]-$tmp[0]+1 < $fine_star_rang))){
				$fine_star_ovlp = $tmp[2]-$tmp[1]+1;
				$fine_star_rang = $tmp[3]-$tmp[0]+1;
				$fine_star_id   = $star_id{$_}[$i/2];
				$star_stt = $star_reads{$_}[$i];
				$star_end = $star_reads{$_}[$i+1];
			}
		}
	}
	$fine_star_id = "-\t-" unless ($fine_star_id);
	my @pre_pos = split /:/,$mature_info{$_};
	my $pre_pos_strand = (split /\s/,$pre_pos[3])[0];
	my $star_chr_stt = $star_stt+$pre_pos[1]-1;
	my $star_chr_end = $star_end+$pre_pos[1]-1;
	if ($pre_pos_strand eq '-'){
		$star_chr_stt = $pre_pos[2]-$star_end+1;
		$star_chr_end = $pre_pos[2]-$star_stt+1;
	}
	my $real_star_id = $ori_seq_id{"$pre_pos[0]:$pre_pos_strand:$star_chr_stt:$star_chr_end"};
	my $real_star_seq = (split /\t/,$fine_star_id)[1];
	$real_star_id = "-" unless ($real_star_id);
	print OUT "$_\t$mature_seq{$_}\t$clus_num\t$real_star_id\t$real_star_seq\t$mature_info{$_}\n";
}
close OUT;
############################ Substitude #########################################
my %samp_reads;
open IN  ,  "SAMP-smap.sRNA" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	my $id    = shift @lines;
	$samp_reads{$id} = join("_", @lines);
}
close IN;

open IN  ,  "Final_PreDict_miRNA.1ln" or die $!;
open OUT ,  ">Final_PreDict_miRNA_samp.1ln" or die $!;
while (<IN>){
	chomp;
	my @lines = split /\t/,$_;
	my @tags  = split /\_/, $lines[0];
	$tags[0]  =~ s/>//g;
	pop(@tags);
	$lines[0] = ">".join("_", @tags)."_".$samp_reads{$tags[0]};
	print OUT join("\t", @lines)."\n";
}
close IN;
close OUT;

open IN  ,  "SAMP-mapping-RF" or die $!;
open OUT ,  ">SAMP-mapping-RF-samp" or die $!;
while (<IN>){
        chomp;
        my @lines = split /\t/,$_;
        my @tags  = split /\_/, $lines[0];
        pop(@tags);
        $lines[0] = join("_", @tags)."_".$samp_reads{$tags[0]};
        print OUT join("\t", @lines)."\n";
}
close IN;
close OUT;

open IN  ,  "Final_PreDict_miRNA.StarInfo" or die $!;
open OUT ,  ">Final_PreDict_miRNA_samp.StarInfo" or die $!;
while (<IN>){
        chomp;
        my @lines = split /\t/,$_;
        my @tags  = split /\_/, $lines[0];                                                                               
        pop(@tags);
        $lines[0] = join("_", @tags)."_".$samp_reads{$tags[0]};
	if ($lines[3] ne '-'){
		my @star  = split /\_/, $lines[3];
		pop(@star);
		$lines[3] = join("_", @star)."_".$samp_reads{$star[0]};
        }
	print OUT join("\t", @lines)."\n";                                                                               
}
close IN;
close OUT;

################################################################################

#################################################################################
print "Draw Mapped Reads...\n";
############################ Draw Mapped Reads ##################################
&Draw_Map_Reads::_Draw_Map_Reads("Final_PreDict_miRNA_samp.1ln", "SAMP-mapping-RF-samp", "Final_PreDict_miRNA.Reads");
#################################################################################
print "Delete inter File...\n";
############################ Delete inter File ##################################
unlink glob ".tmp*";
unlink "Candidate_Pre.fa", "Final_PreDict_miRNA.list", "Final_PreDict_miRNA_Ref.1ln", "SAMP-Loci-Reads";
unlink "Candidate_Pre_GoodStruc", "Final_PreDict_miRNA.1ln", "Final_PreDict_miRNA_Ref.cluster";
unlink "Final_PreDict_miRNA_Ref.Mapped", "Final_PreDict_miRNA_samp.1ln", "Final_PreDict_miRNA.StarInfo";
unlink "SAMP-mapping", "SAMP-mapping-RF", "SAMP-mapping-RF-samp", "SAMP-RF-smRNACluster.miRNA";
unlink "SAMP-smap.sRNA", "SAMP.sRNA";




