#include <stdio.h>


int main() {
  printf("%s", PKGDATADIR) ;
  return 0 ;
}
